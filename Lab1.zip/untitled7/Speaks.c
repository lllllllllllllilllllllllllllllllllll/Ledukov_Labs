#include <stdio.h>
const char *read_filename1() {
    printf("Input filename-source: \n");
    //return "C:\\Ci\\16.bmp";
    static char filename[1001];
    scanf("%1000s", filename);
    return filename;
}

const char *read_filename2() {
    printf("Input filename-destination: \n");
    //return "C:\\Ci\\2.bmp";
    static char filename[1001];
    scanf("%1000s", filename);
    return filename;
}
