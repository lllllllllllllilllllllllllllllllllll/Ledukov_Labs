#include "Libr.h"

int main(){
    const char* filename= read_filename1();
    FILE* file;
    fopen_s(&file,filename,"rb");
    if(file == NULL) {
        printf("File <%s> not found", filename);
        return 2;
    }
    bmpH1 = (struct bmp_header*)calloc(1, sizeof(struct bmp_header));
    enum read_status rs=read_header(file);
    if (rs==READ_OK){
        uint32_t my = bmpH1->biWidth;
        uint32_t mx = bmpH1->biHeight;
        create_img(&img1, mx, my);
        rs=from_bmp( file, img1);
        fclose(file);
        free(bmpH1);
        if (rs==READ_OK){
            filename = read_filename2();
            fopen_s(&file,filename,"wb");
            if(file == NULL) {
                printf("Error writing to file <%s>", filename);
                fclose(file);
                destroy_img(&img1);
                return WRITE_ERROR;
            }
            create_img(&img2, my, mx);
            img2=rotate(img1);
            destroy_img(&img1);
            create_bmp_header( my, mx);
            check_Header();
            check_pix(img2.data[0]);
            enum write_status ws = write_header(file);
            if (ws==WRITE_OK){
                ws = to_bmp(file, img2);
                destroy_img(&img2);
                fclose(file);
                if (ws==WRITE_OK){
                    printf("The file <%s> was created successfully", filename);
                    return 0;
                }
                printf("Error writing to file <%s>", filename);
                return 5;
            }
            destroy_img(&img2);
            printf("Error writing to file <%s>", filename);
            return 4;
        }
        printf("Error image in file <%s>", filename);
        destroy_img(&img1);
        return 3;
    }
    printf("Error Header in file <%s>", filename);
    fclose(file);
    return 1;
}


